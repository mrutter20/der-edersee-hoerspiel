# Der Edersee – Android-Hörspiel-App (Startversion)

Diese Startversion ist ein natives Android-Projekt. Sie nutzt die auf dem Gerät installierte Android-Text-in-Sprache-Engine und verursacht selbst keine API-Gebühren. Welche Stimmen kostenlos und offline verfügbar sind, hängt vom Handy und der installierten TTS-Engine ab.

## Funktionen der Startversion
- feste Rollen: ERZÄHLER, MARTIN, ANDREA
- auswählbare deutsche TTS-Stimmen pro Rolle
- zeilenweise Sprachsynthese und Zusammenfügen in eine WAV-Datei
- Export über den Android-Dateidialog

## Noch nicht enthalten
- Musik und Soundeffekte
- Speichern des kompletten Projekts nach App-Neustart
- MP3-Encoding (Export ist WAV)
- automatische Bereinigung und Pausen-/Szenenregie
- vollständiger Gerätetest

## Bauen
Das Projekt verwendet Android Gradle Plugin 8.7.3 und Kotlin 2.0.21. Es kann in Android Studio gebaut werden oder über die beigefügte GitHub-Actions-Datei, wenn das Projekt in ein GitHub-Repository hochgeladen wird.
