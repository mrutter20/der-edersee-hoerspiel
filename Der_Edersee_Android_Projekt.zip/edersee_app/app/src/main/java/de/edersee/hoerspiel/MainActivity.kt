package de.edersee.hoerspiel

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var script: EditText
    private lateinit var status: TextView
    private lateinit var narratorSpinner: Spinner
    private lateinit var martinSpinner: Spinner
    private lateinit var andreaSpinner: Spinner
    private lateinit var makeButton: Button
    private lateinit var exportButton: Button
    private var ready = false
    private var voices: List<Voice> = emptyList()
    private val executor = Executors.newSingleThreadExecutor()
    private var finalFile: File? = null
    private var pendingLines: List<Pair<String, String>> = emptyList()
    private var pendingFiles: MutableList<File> = mutableListOf()
    private var pendingIndex = 0
    private var pendingVoice: Voice? = null
    private var pendingText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(52, 35, 31)
        window.navigationBarColor = android.graphics.Color.rgb(52, 35, 31)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(android.graphics.Color.rgb(249, 245, 239))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "DER EDERSEE\nEine Liebesgeschichte, die noch lange nicht zu Ende ist"
            textSize = 23f; setTextColor(android.graphics.Color.rgb(52, 35, 31));
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 0, 0, dp(8))
        }
        content.addView(title)
        content.addView(label("Einmaliges Hörspielprojekt · kostenlose Handy-Stimmen"))
        content.addView(section("1 · FESTE STIMMEN"))
        narratorSpinner = addVoicePicker(content, "Erzähler")
        martinSpinner = addVoicePicker(content, "Martin")
        andreaSpinner = addVoicePicker(content, "Andrea")
        content.addView(section("2 · GESCHICHTE"))
        content.addView(label("Jede Zeile beginnt mit ERZÄHLER:, MARTIN: oder ANDREA:. Die Stimmen bleiben diesen Rollen zugeordnet."))
        script = EditText(this).apply {
            minLines = 10; gravity = android.view.Gravity.TOP; textSize = 15f
            setTextColor(android.graphics.Color.rgb(40, 35, 32))
            setHint("ERZÄHLER: Am Edersee begann ihre Geschichte.\nMARTIN: Ich weiß noch, wie ich dich zum ersten Mal sah.\nANDREA: Und ich erinnere mich an unseren ersten Kuss.")
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(script, LinearLayout.LayoutParams(-1, dp(240)))
        makeButton = Button(this).apply {
            text = "Hörspiel als Audio erzeugen"
            setOnClickListener { generateAudio() }
        }
        content.addView(makeButton, marginParams(top = 12))
        exportButton = Button(this).apply {
            text = "Fertige MP3 / Audiodatei exportieren"
            isEnabled = false
            setOnClickListener { exportAudio() }
        }
        content.addView(exportButton, marginParams(top = 4))
        status = TextView(this).apply {
            text = "Bereit. Die Qualität und Auswahl hängen von den auf deinem Handy installierten deutschen Sprachstimmen ab."
            textSize = 14f; setTextColor(android.graphics.Color.rgb(90, 70, 62)); setPadding(0, dp(12), 0, 0)
        }
        content.addView(status)
        content.addView(section("WICHTIG"))
        content.addView(label("Diese erste Version nutzt die kostenlose Android-Sprachausgabe. Sie benötigt keinen kostenpflichtigen Sprachdienst. Musik und Geräusche sind noch nicht eingebaut. Beim Erzeugen werden die Rollen abschnittsweise gesprochen."))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(android.graphics.Color.rgb(85, 69, 62)); setPadding(0, dp(3), 0, dp(8))
    }
    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
        setTextColor(android.graphics.Color.rgb(141, 75, 56)); setPadding(0, dp(18), 0, dp(7))
    }
    private fun addVoicePicker(parent: LinearLayout, role: String): Spinner {
        parent.addView(label(role))
        return Spinner(this).also { spinner ->
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Lade deutsche Stimmen …"))
            parent.addView(spinner, marginParams(bottom = 5))
        }
    }
    private fun marginParams(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(top); bottomMargin = dp(bottom)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onInit(statusCode: Int) {
        runOnUiThread {
            if (statusCode != TextToSpeech.SUCCESS) { status.text = "Die Android-Sprachausgabe konnte nicht gestartet werden."; return@runOnUiThread }
            val lang = tts.setLanguage(Locale.GERMAN)
            voices = (tts.voices ?: emptySet()).filter { it.locale.language == "de" && !it.isNetworkConnectionRequired }.sortedBy { it.name.lowercase(Locale.ROOT) }
            if (voices.isEmpty()) voices = (tts.voices ?: emptySet()).filter { it.locale.language == "de" }.sortedBy { it.name.lowercase(Locale.ROOT) }
            val labels = voices.map { "${it.name}${if (it.isNetworkConnectionRequired) " · online" else " · lokal"}" }.ifEmpty { listOf("Keine deutsche Stimme gefunden") }
            listOf(narratorSpinner, martinSpinner, andreaSpinner).forEach { s ->
                s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
            }
            ready = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED && voices.isNotEmpty()
            makeButton.isEnabled = ready
            status.text = if (ready) "${voices.size} deutsche Stimme(n) gefunden. Wähle nach Klang und teste dann dein Hörspiel." else "Keine passende deutsche Stimme gefunden. Öffne Android-Einstellungen → Text-in-Sprache und installiere deutsche Sprachdaten."
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String) {}
                override fun onError(utteranceId: String) { runOnUiThread { fail("Ein Sprachabschnitt konnte nicht erzeugt werden.") } }
                override fun onDone(utteranceId: String) { runOnUiThread { onSpeechDone() } }
            })
        }
    }

    private fun generateAudio() {
        if (!ready) { status.text = "Die Sprachstimmen sind noch nicht bereit."; return }
        val rows = script.text.toString().lines().map { it.trim() }.filter { it.isNotBlank() }
        val parsed = mutableListOf<Pair<String, String>>()
        for (row in rows) {
            val idx = row.indexOf(':')
            if (idx <= 0) { fail("Bitte jede Textzeile mit ERZÄHLER:, MARTIN: oder ANDREA: beginnen."); return }
            val role = row.substring(0, idx).trim().uppercase(Locale.ROOT)
            val text = row.substring(idx + 1).trim()
            if (role !in setOf("ERZÄHLER", "MARTIN", "ANDREA")) { fail("Unbekannte Rolle: $role. Erlaubt sind ERZÄHLER, MARTIN und ANDREA."); return }
            if (text.isNotBlank()) parsed.add(role to text)
        }
        if (parsed.isEmpty()) { fail("Füge zuerst die Geschichte ein."); return }
        pendingLines = parsed
        pendingFiles = mutableListOf()
        pendingIndex = 0
        makeButton.isEnabled = false; exportButton.isEnabled = false
        status.text = "Erzeuge 0 von ${pendingLines.size} Sprachabschnitten … Bitte die App geöffnet lassen."
        speakNext()
    }

    private fun speakNext() {
        if (pendingIndex >= pendingLines.size) {
            executor.execute {
                try {
                    val out = File(getExternalFilesDir(null), "Der_Edersee.wav")
                    mergeWavFiles(pendingFiles, out)
                    runOnUiThread {
                        finalFile = out; makeButton.isEnabled = true; exportButton.isEnabled = true
                        status.text = "Fertig! Die Audiodatei wurde erstellt. Tippe auf Export, um sie in einen Ordner deiner Wahl zu speichern."
                    }
                } catch (e: Exception) { runOnUiThread { fail("Zusammenfügen fehlgeschlagen: ${e.message ?: "unbekannter Fehler"}") } }
            }
            return
        }
        val (role, text) = pendingLines[pendingIndex]
        val spinner = when (role) { "MARTIN" -> martinSpinner; "ANDREA" -> andreaSpinner; else -> narratorSpinner }
        pendingVoice = voices.getOrNull(spinner.selectedItemPosition) ?: voices.firstOrNull()
        pendingText = text
        val file = File(cacheDir, "part_${pendingIndex}.wav")
        file.delete()
        pendingFiles.add(file)
        pendingVoice?.let { tts.voice = it }
        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        val result = tts.synthesizeToFile(text, params, file, "part_${pendingIndex}")
        if (result == TextToSpeech.ERROR) fail("Die Sprachsynthese konnte nicht gestartet werden.")
    }

    private fun onSpeechDone() {
        pendingIndex++
        status.text = "Erzeuge ${pendingIndex} von ${pendingLines.size} Sprachabschnitten …"
        speakNext()
    }

    private fun mergeWavFiles(parts: List<File>, output: File) {
        val dataChunks = mutableListOf<ByteArray>()
        var sampleRate = 22050
        var channels = 1
        var bits = 16
        for (f in parts) {
            if (!f.exists() || f.length() < 44) throw IllegalStateException("Ein Audioabschnitt ist leer")
            val bytes = f.readBytes()
            if (String(bytes, 0, 4, Charsets.US_ASCII) != "RIFF" || String(bytes, 8, 4, Charsets.US_ASCII) != "WAVE") throw IllegalStateException("Die installierte Stimme liefert kein WAV-Format. Dieses Handy benötigt dann eine andere Exportmethode.")
            var p = 12; var data: ByteArray? = null
            while (p + 8 <= bytes.size) {
                val id = String(bytes, p, 4, Charsets.US_ASCII)
                val size = leInt(bytes, p + 4).coerceAtLeast(0)
                val start = p + 8
                if (start + size > bytes.size) break
                if (id == "fmt " && size >= 16) { channels = leShort(bytes, start + 2); sampleRate = leInt(bytes, start + 4); bits = leShort(bytes, start + 14) }
                if (id == "data") { data = bytes.copyOfRange(start, start + size); break }
                p = start + size + (size % 2)
            }
            dataChunks.add(data ?: throw IllegalStateException("Kein Audiodaten-Block gefunden"))
        }
        val total = dataChunks.sumOf { it.size }
        FileOutputStream(output).use { out ->
            out.write("RIFF".toByteArray(Charsets.US_ASCII)); writeInt(out, 36 + total)
            out.write("WAVEfmt ".toByteArray(Charsets.US_ASCII)); writeInt(out, 16)
            writeShort(out, 1); writeShort(out, channels); writeInt(out, sampleRate)
            writeInt(out, sampleRate * channels * bits / 8); writeShort(out, channels * bits / 8); writeShort(out, bits)
            out.write("data".toByteArray(Charsets.US_ASCII)); writeInt(out, total)
            dataChunks.forEach { out.write(it) }
        }
    }
    private fun leInt(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p+1].toInt() and 255) shl 8) or ((b[p+2].toInt() and 255) shl 16) or ((b[p+3].toInt() and 255) shl 24)
    private fun leShort(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p+1].toInt() and 255) shl 8)
    private fun writeInt(out: FileOutputStream, n: Int) { out.write(n and 255); out.write((n shr 8) and 255); out.write((n shr 16) and 255); out.write((n shr 24) and 255) }
    private fun writeShort(out: FileOutputStream, n: Int) { out.write(n and 255); out.write((n shr 8) and 255) }

    private fun exportAudio() {
        val file = finalFile ?: return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/wav"; putExtra(Intent.EXTRA_TITLE, "Der_Edersee.wav")
        }
        startActivityForResult(intent, 4001)
    }
    @Deprecated("Deprecated in Android API; kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4001 && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val file = finalFile ?: return
            try { contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(file).use { it.copyTo(out) } }; status.text = "Audiodatei gespeichert." }
            catch (e: Exception) { status.text = "Export fehlgeschlagen: ${e.message}" }
        }
    }
    private fun fail(message: String) {
        makeButton.isEnabled = ready
        status.text = message
    }
    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdown()
        super.onDestroy()
    }
}
